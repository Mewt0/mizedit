birds_avail						= true		--Birds availability. false - there is no birds
birds_maximum_hrad				= 200		--Maximum altitude above ground al sea level bird could be met
birds_maximum_absolute_height	= 8000		--Maximum absolute altitude bird could be met
birds_minimum_velocity			= 40		--Minimum velocity bird could be met
birds_delta_time				= 3.55
birds_probability = {0.006333333*150, 
			0.004166667*150, 
			0.001966667*150, 
			0.001090909*150, 
			0.000741818*150, 
			0.0006*150, 
			0.000510545*150, 
			0.000447273*150, 
			0.000389455*150,
			0.000349091*150,
			0.000310909*150,
			0.000282545*150,
			0.000250909*150,
			0.000220364*150,
			0.000196364*150,
			0.000174545*150,
			0.000152727*150,
			0.000128727*150,
			0.000103636*150,
			7.63636E-05*150,
			0*150
}
